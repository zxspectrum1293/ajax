<p align="center" class="title">Навигация</p>

<div id="coolmenu">
    <a href="index.php">Главная</a>
    <a href="products.php">Наш ассортимент</a>
    <a href="contacts.php">Контакты</a>
    <a href="about.php">О нас</a>
</div>