<?php
// Подключение к базе данных
$db = mysqli_connect("localhost", "root", "", "bakery");
?>