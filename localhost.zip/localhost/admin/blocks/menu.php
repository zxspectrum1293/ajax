<p align="center" class="title">Категории выпечки</p>

<div id="coolmenu">
    <a href="page_add_category.php">Добавление</a>
    <a href="page_edit_category.php">Редактирование</a>
    <a href="page_delete_category.php">Удаление</a>
</div>


<p align="center" class="title">Выпечка</p>

<div id="coolmenu">
    <a href="page_add_product.php">Добавление</a>
    <a href="page_edit_product.php">Редактирование</a>
    <a href="page_delete_product.php">Удаление</a>
</div>

